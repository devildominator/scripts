﻿HotShots is an application for capturing screens and saving them in a variety of image formats as well as adding annotations and graphical data (arrows, lines, texts, ...).
You can also upload your creations to the web (FTP/some web services).
Because HotShots is written with Qt, HotShots runs on Windows, Linux (MacOSX isn't tested yet).

You want to help ? You can proposed you as translator on transifex.com (HotShots project) or post feedbacks on SourceForge:
- http://sourceforge.net/p/hotshots/tickets for bug report or feature request
- http://sourceforge.net/p/hotshots/discussion/ for general feedbacks

You can also help me by correcting my brief help page (I'm sure you've noticed that English is not my mother tongue! :)) Contact me xbee at xbee dot net